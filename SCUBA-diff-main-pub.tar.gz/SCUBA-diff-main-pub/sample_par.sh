# !/bin/bash

conda activate torch101

name=sketch_mask90_domain_tune_noceaatype_minbatch_sketch_mask

testlist=demo/gen_from_noise/gen_from_noise_sample.txt
# testlist=demo/loop_sampling/loop_sampling.txt
# testlist=demo/refine_prior/refine_prior.txt


CUDA_VISIBLE_DEVICES=1 python3.8 inference_par.py \
    --root_dir savedir/${name} \
    --test_list ${testlist} \
    --max_sample_num 1000000 \
    --write_pdbfile \
    --batch_size 2 \
    --sample_from_raw_pdbfile \
    --epoch_num 4 \
    --diff_noising_scale 0.1 \
    --iterate_mode structure_gen_from_sstype \
    --model_path savedir/${name}/checkpoint/checkpoint_last.pt \