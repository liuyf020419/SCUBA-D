import os
import json
from multiprocessing import Pool


import numpy as np
import pandas as pd

workers = 4

pool = Pool(workers)

def write_resfile(outputroot, id_list, seq_list, chain):
    with open(os.path.join(outputroot, "resfile" + "_" + chain), "w") as writer:
        writer.write("default nat" + "\n")
        for id, aa in zip(id_list, seq_list):
            writer.write(chain + " " + str(id) + " " + aa + " " + "\n")


def write_fasta(outputroot, seq, seqname):
    with open(os.path.join(outputroot, seqname + ".fasta"), "w") as writer:
        writer.write(">" + seqname + "\n")
        writer.write(seq.strip())


def get_model_id(inf):
    id_list = []
    with open(inf, "r") as reader:
        for line in reader.readlines():
            id_list.append(int(line.strip().split("+")[1]))
    return id_list


def parse_seq_design(seqlines):
    design_dict = {}
    for line in seqlines:
        tmpdict = json.loads(line.strip())
        design_dict.update({list(tmpdict.keys())[0]: list(tmpdict.values())[0]})

    return design_dict


def get_model_seq(inf):
    with open(inf) as seqf:
        seqlines = seqf.readlines()
    entry = parse_seq_design(seqlines)

    return entry


def parse_fasta(fas_file):
    score_list = []
    seqs_list = []
    with open(fas_file, 'r') as reader:
        for l_idx, line in enumerate(reader.readlines()):
            if l_idx in [0, 1]:
                continue
            else:
                if (l_idx % 2 == 0):
                    score_list.append( float(line.strip().split(',')[2].split('score=')[1].strip()) )
                else:
                    seqs_list.append( line.strip() )

    return score_list, seqs_list   



if __name__ == '__main__':

    fastadir = "/home/liuyf/alldata/monomer_joint_PriorDDPM_ESM1b_Dnet_LE_MPNN_LC_trans_newmask_20221123/demo_new/hallucination/6mgh_gen_from_init_barrel/af2_pred/AF2_fasta"
    af2_pred_dir = "/home/liuyf/alldata/monomer_joint_PriorDDPM_ESM1b_Dnet_LE_MPNN_LC_trans_newmask_20221123/demo_new/hallucination/6mgh_gen_from_init_barrel/af2_pred/AF2_pred"
    mpnn_root_dir = "/home/liuyf/alldata/monomer_joint_PriorDDPM_ESM1b_Dnet_LE_MPNN_LC_trans_newmask_20221123/demo_new/hallucination/6mgh_gen_from_init_barrel/mpnn_design/outputs/seqs"

    GPU_idx = 0
    lowest_energy_for_pred = 2
    
    def nodewrapAF2(YOUR_FASTA_FORMAT_SEQ_FILE, out_root, GPU_idx):
        os.system(
            f'bash /home/hbfrank/usr/local/alphafold2_ws/alphafold2/run_local.sh -i {YOUR_FASTA_FORMAT_SEQ_FILE} -P 0 -g {GPU_idx} -o {out_root}')

    os.makedirs(af2_pred_dir, exist_ok=True)
    
    fa_list = [f'{mpnn_root_dir}/{f}' for f in os.listdir(mpnn_root_dir)]

    for fa_f in fa_list:
        protein = '.'.join(os.path.basename(fa_f).split('.')[:-1])
        score_list, seqs_list = parse_fasta(fa_f)

        for idx, seq in enumerate(seqs_list):
            os.makedirs(f'{fastadir}/{protein}_{idx}', exist_ok=True)

            write_fasta(fastadir + "/" + protein + "_" + str(idx), seq, protein + "_" + str(idx))

            YOUR_FASTA_FORMAT_SEQ_FILE = fastadir + "/" + protein + "_" + str(idx) + "/" + protein + "_" + str(idx) + ".fasta"
            af2_pred_out_dir = f'{af2_pred_dir}'

            if os.path.isfile(f'{af2_pred_out_dir}/{protein + "_" + str(idx)}/ranking_debug.json'):
                continue
            else:
                print(f'{protein}_{idx}')
                # nodewrapAF2(YOUR_FASTA_FORMAT_SEQ_FILE, af2_pred_out_dir, GPU_idx)
                pool.apply_async(func=nodewrapAF2, args=(YOUR_FASTA_FORMAT_SEQ_FILE, af2_pred_out_dir, GPU_idx,))

    pool.close()
    pool.join()
