import os
import json
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

from pytmalign import TMalign

tmaligner = TMalign()

def plot_af2_dist(data_list, pngfile, label='rmsd', bins=20): 
    plt.figure() 
    bwith =2
    ax = plt.gca()
    ax.spines["bottom"].set_linewidth(bwith) 
    ax.spines["left"].set_linewidth(bwith) 
    ax.spines["top"].set_linewidth(bwith) 
    ax.spines['right'].set_linewidth(bwith)
    
    sns.distplot(
        data_list,rug=False, kde=False, norm_hist=True, label=label, bins=bins, 
        hist_kws={"histtype": "step","linewidth": 3.0,"alpha":1.0},)
    # plt.xlabel(fontsize=20)
    plt.yticks(size=15) 
    plt.xticks(size=15)
    plt.tick_params(width=bwith)
    # plt.legend(frameon = True, fontsize = 15)
    # plt.grid(b=True)# plt.x1im(2.5，22.5)# plt.ylim(0,0.3)
    plt.tight_layout() 
    plt.savefig(pngfile)
    
    
    
def plt_af2_scatter(trajs_align_dict, pngfile, x_metrics='RMSD', y_metrics='pLDDT'): 
    plt.figure(figsize=[7,7]) 
    bwith = 2
    ax = plt.gca()
    ax.spines["bottom"].set_linewidth(bwith) 
    ax.spines["left"].set_linewidth(bwith) 
    ax.spines["top"].set_linewidth(bwith) 
    ax.spines['right'].set_linewidth(bwith)
    

    sns.scatterplot(x=x_metrics, y=y_metrics, 
                    # hue="refine step",
                    # palette={"7fbb":"lightblue","7fbc": "orange","7fbd": "purple"}, 
                    data=trajs_align_dict,
                    s=100,edgecolor="black",linewidth=2.5,alpha=0.7
                    )
    
    plt.yticks(size=15) 
    plt.xticks(size=15)
    plt.xlabel(x_metrics, fontsize=20)
    plt.ylabel(y_metrics, fontsize=20)
    plt.tick_params(width=bwith)
    # plt.legend(frameon = True, fontsize =15)
    # plt.grid(b=True)# plt.xlim(2.5，22.5)# plt.ylim(0,0.3)
    plt.tight_layout() 
    plt.savefig(pngfile)
    
    
def plt_af2_joint(trajs_align_dict, pngfile, x_metrics='RMSD', y_metrics='pLDDT'): 
    plt.figure(figsize=[7,7]) 
    bwith = 2
    ax = plt.gca()
    ax.spines["bottom"].set_linewidth(bwith) 
    ax.spines["left"].set_linewidth(bwith) 
    ax.spines["top"].set_linewidth(bwith) 
    ax.spines['right'].set_linewidth(bwith)
    
    ax = sns.jointplot(x=x_metrics, y=y_metrics, data=trajs_align_dict,
                  height=7, ratio=3, alpha=0.7, s=70,
                  marginal_kws={"bins":20, "alpha":0.7})
    if x_metrics != 'pLDDT':
        x_metrics = 'sc ' + x_metrics
    if y_metrics != 'pLDDT':
        y_metrics = 'sc ' + y_metrics 
    ax.set_axis_labels(x_metrics, y_metrics, fontsize=20)
    ax.ax_joint.tick_params(axis='both',labelsize=20, width=2)
    ax.ax_marg_x.tick_params(axis='both',labelsize=20, width=2)
    ax.ax_marg_y.tick_params(axis='both',labelsize=20, width=2)
    plt.tight_layout() 
    plt.savefig(pngfile)
    
    
def parse_colabfold_plddt_rmsd(json_file: str, colab_pred_pdbfiles: str, ref_pdb_file: str): 
    with open(json_file) as f:
        randing_dict = json.load(f)
    plddt_list = list(randing_dict['plddts'].values())
    plddt_max = np.max(plddt_list)
    rmsd_list, tmscore_list = [], []
    for colab_pred_pdb_file in colab_pred_pdbfiles:
        tmscore,rmsd,_,_=tmaligner.run(colab_pred_pdb_file, ref_pdb_file, chainA='A', chainB='A') 
        rmsd_list.append(rmsd)
        tmscore_list.append(tmscore) 
        tmscore_max = np.max(tmscore_list) 
        rmsd_min = np.min(rmsd_list)
    return tmscore_max, rmsd_min, plddt_max


if __name__ == '__main__':
    colab_pred_root = '/home/liuyf/Workshop/SCUBA-D-experiment/gen_from_sstype_refine_loop/af2_pred/AF2_pred'
    ref_pdb_root = '/home/liuyf/Workshop/SCUBA-D-experiment/gen_from_sstype_refine_loop/mpnn_design/PDBfile'
    out_prefix = 'gen_from_sstype_refine_loop'
    
    af2_pred_root = []
    potential_data_list = []
    tmscore_list = []
    rmsd_list = []
    plddt_list = []
    min_rmsd_pdbname_list = []
    max_plddt_pdbname_list = []

    pdbname_list=list(set([ '-'.join(pdbname.split('-')[:6] ) for pdbname in os.listdir(colab_pred_root) ]))  
    import pdb; pdb.set_trace()
    for pdbname in pdbname_list:
        pdbfiles = [f for f in os.listdir(colab_pred_root) if pdbname in f]

        for pdbfile in pdbfiles:
            single_colab_pred_pdb_files = [f'{colab_pred_root}/{pdbfile}/ranked_{pred_idx}.pdb' for pred_idx in range(5)]
            single_json= f'{colab_pred_root}/{pdbfile}/ranking_debug.json'
            if not os.path.isfile(single_json):
                continue
            single_ref_pdb_file=f'{ref_pdb_root}/{pdbfile[:-2]}.pdb'
            tmscore,rmsd,plddt=parse_colabfold_plddt_rmsd(single_json, single_colab_pred_pdb_files, single_ref_pdb_file) 

            if ((plddt > 85) and (tmscore > 0.85) and (rmsd < 2.5)):
                potential_data_list.append(single_ref_pdb_file)
                af2_pred_root.append(f'{colab_pred_root}/{pdbfile}')
                tmscore_list.append(tmscore)
                rmsd_list.append(rmsd)
                plddt_list.append(plddt)
        
    trajs_align_dict ={
        'ref_pdb_f': potential_data_list,
        'pred_pdb_dir': af2_pred_root,
        'RMSD': np.array(rmsd_list), 
        'TM-score': np.array(tmscore_list),
        'pLDDT': np.array(plddt_list)
        }
    
    pd.DataFrame.from_dict(trajs_align_dict).to_csv(f'./{out_prefix}.csv')
    np.save(f'{out_prefix}.npy', trajs_align_dict)
    
    