# SCUBA-D
This is a preliminary version of our code. We are in the process of cleaning up the code for training and will be open sourcing the complete code soon.

Please refer to the [SCUBA-D paper](https://www.biorxiv.org/content/10.1101/2022.12.17.520847v1) for more details on the algorithm.

To run SCUBA-D, clone this GitHub repository and install Python.
## Install python environment via requirements file
```bash
pip install -r requirements.txt
```

Input for `sample_par.sh` is a text file that contains controls for each design.
The following options are suggested to be manually changed according to your needs:

* `CUDA_VISIBLE_DEVICES` - visible GPU idx
* `test_list` - list of designs
* `max_sample_num` - maximum number of runs in the list, default is 10,000,000.
* `batch_size` - number of designs for each batch
* `epoch_num` -  number of iterations for each design, default is 4.

## Control Templates
All controls of the design are set in a JSON file. For convenience, we have provided some templates for different usages as references:
* `demo/gen_from_noise/gen_from_all_noise.json` - unconditional generation from noise
* `demo/gen_from_noise/gen_from_all_sstype.json` - generation with provided secondary structure as prior
* `demo/gen_from_noise/gen_from_noise_partial_fixed.json` - unconditional generation but fix some coordinates of motifs
* `demo/refine_prior/structure_refine.json` - refine the provided structure
* `demo/loop_sampling/loop_sampling.json` - reconstruct specified loops and fix coordinates of the rest of residues

Users can also create their own templates by changing the parser in `protdiff/dataset/refine_dataset_par.py`.

To provide more specific details on how to use the provided templates, see `demo/README.md` for more details.

-----------------------------------------------------------------------------------------------------
Output example in target dir:
```
gen_from_all_noise.json
gen_from_all_noise_diff_term_0_scale_0.1_batch_1.pdb
gen_from_all_noise_diff_term_1_scale_0.1_batch_0.pdb
gen_from_all_noise_diff_term_1_scale_0.1_batch_1.pdb
gen_from_all_noise_diff_term_2_scale_0.1_batch_0.pdb
gen_from_all_noise_diff_term_2_scale_0.1_batch_1.pdb
gen_from_all_noise_diff_term_3_scale_0.1_batch_0.pdb
gen_from_all_noise_diff_term_3_scale_0.1_batch_1.pdb
```
* `term_X` - index of iteration
* `batch_X` - index of batch
-----------------------------------------------------------------------------------------------------
