from .dataset_par import ProtDiffParDataset
